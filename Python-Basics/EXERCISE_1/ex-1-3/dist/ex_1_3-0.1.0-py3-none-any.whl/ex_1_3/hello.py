def say_hello(name: str) -> str:
    """Return a greeting message."""
    return f"Hello, {name}!"

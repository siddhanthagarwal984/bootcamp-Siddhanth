# Siddhanth WF Dynamic
A YAML-driven text processing pipeline.

## Installation
```sh
poetry install

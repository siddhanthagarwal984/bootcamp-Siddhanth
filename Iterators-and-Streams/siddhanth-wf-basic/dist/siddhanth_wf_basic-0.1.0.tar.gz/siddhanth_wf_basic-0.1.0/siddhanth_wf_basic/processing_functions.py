import os

def upper_case(input_file, output_file=None):
    if output_file is None:
        output_file = input_file + ".processed"
    
    with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
        for line in infile:
            outfile.write(line.upper())

def lower_case(input_file, output_file=None):
    if output_file is None:
        output_file = input_file + ".processed"

    with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
        for line in infile:
            outfile.write(line.lower())
